package com.example.MTConnect.data;

import com.opencsv.CSVReaderHeaderAware;
import com.opencsv.exceptions.CsvValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * CSVDataReader — источник "сырых" данных из CSV.
 * - читает CSV с заголовком (OpenCSV CSVReaderHeaderAware);
 * - отдаёт по строке как Map<column, value>;
 * - по EOF может "крутиться по кругу" (loopAtEof);
 * - умеет читать как из classpath:..., так и из внешнего пути.
 *
 * Конфигурация (application.yml / args / env):
 *   sim.csvPath: "" (по умолчанию) -> classpath:data.csv
 *                 "classpath:foo.csv" -> ресурсы
 *                 "/abs/path/file.csv" -> внешний путь
 *   sim.loopAtEof: true|false
 */
@Component
public class CSVDataReader implements Closeable {

    private static final Logger log = LoggerFactory.getLogger(CSVDataReader.class);

    // ---- Конфиг / состояние ----
    private String csvPath;      // может меняться через reload()
    private boolean loopAtEof;   // может меняться через reload()

    private Reader reader;
    private CSVReaderHeaderAware csv;
    private boolean closed = true;

    // Счётчики и диагностика
    private final AtomicLong reopenCount = new AtomicLong(0);
    private final AtomicLong rowCounter  = new AtomicLong(0);

    // --- основной конструктор: Spring подставит значения ---
    public CSVDataReader(
            @Value("${sim.csvPath:}") String configuredCsvPath,
            @Value("${sim.loopAtEof:true}") boolean loopAtEof
    ) {
        this.csvPath  = (configuredCsvPath == null) ? "" : configuredCsvPath.trim();
        this.loopAtEof = loopAtEof;
        reopen();
    }

    /**
     * Главный метод: вернуть следующую строку как Map<Header,Value>.
     * Потокобезопасен.
     *
     * @return Map<String,String> или null, если EOF и loopAtEof=false
     */
    public synchronized Map<String, String> getNextRow() {
        ensureOpen();
        try {
            Map<String, String> row = csv.readMap();

            if (row == null) {
                // EOF
                long readSoFar = rowCounter.get();
                if (!loopAtEof) {
                    if (log.isInfoEnabled()) {
                        log.info("EOF достигнут (прочитано строк: {}). Режим loopAtEof=false — верну null.", readSoFar);
                    }
                    return null;
                }
                if (log.isInfoEnabled()) {
                    log.info("EOF достигнут (прочитано строк: {}). loopAtEof=true — переоткрываю источник и продолжаю с начала.", readSoFar);
                }
                reopen();
                row = csv.readMap(); // может быть null, если файл пуст
                if (row == null) {
                    log.warn("После переоткрытия CSV данных нет (файл пуст?). Возвращаю null.");
                    return null;
                }
            }

            long idx = rowCounter.incrementAndGet();

            if (log.isDebugEnabled()) {
                log.debug("Строка #{}: {}",
                        idx, summarizeRow(row, 5, 80));
            } else if (log.isTraceEnabled()) {
                // На TRACE можно показать весь row (осторожнее с объёмом логов)
                log.trace("Полная строка #{}: {}", idx, row);
            }

            return row;

        } catch (IOException | CsvValidationException e) {
            log.error("Ошибка чтения CSV: {}", e.getMessage(), e);
            throw new RuntimeException("CSV read error: " + e.getMessage(), e);
        }
    }

    /**
     * Горячая смена источника и/или политики EOF.
     * Пример: admin-эндпоинт может дергать этот метод.
     */
    public synchronized void reload(String newCsvPath, Boolean newLoopAtEof) {
        String oldPath = this.csvPath;
        boolean oldLoop = this.loopAtEof;

        if (newCsvPath != null) this.csvPath = newCsvPath.trim();
        if (newLoopAtEof != null) this.loopAtEof = newLoopAtEof;

        log.info("Перезагрузка CSV-источника: path {} -> {}, loopAtEof {} -> {}",
                printable(oldPath), printable(this.csvPath), oldLoop, this.loopAtEof);

        reopen();
    }

    // ================= внутренние методы =================

    /** Переоткрыть источник "с начала" (после заголовка). Потокобезопасно. */
    private synchronized void reopen() {
        closeQuietly();
        try {
            String openWhere;
            if (useClasspath(csvPath)) {
                // classpath:data.csv | "" -> data.csv
                String resourceName = resolveClasspathName(csvPath);
                ClassPathResource resource = new ClassPathResource(resourceName);
                if (!resource.exists()) {
                    throw new IOException("Classpath resource not found: " + resourceName);
                }
                this.reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8);
                openWhere = "classpath:" + resourceName;
            } else {
                // внешний путь
                Path path = Path.of(csvPath);
                this.reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
                openWhere = path.toAbsolutePath().toString();
            }
            this.csv = new CSVReaderHeaderAware(reader); // заголовок будет считан lazily
            this.closed = false;

            long n = reopenCount.incrementAndGet();
            rowCounter.set(0);

            log.info("Открыт CSV (#{}) из '{}'; loopAtEof={}, charset=UTF-8", n, openWhere, loopAtEof);
            log.debug("CSVReaderHeaderAware готов. Заголовок будет считан при первом readMap().");

        } catch (IOException e) {
            String where = useClasspath(csvPath)
                    ? "classpath:" + resolveClasspathName(csvPath)
                    : csvPath;
            log.error("Не удалось открыть CSV '{}': {}", where, e.getMessage(), e);
            throw new RuntimeException("Cannot open CSV file (" + where + "): " + e.getMessage(), e);
        }
    }

    /** Проверка, что поток открыт; при необходимости открыть. */
    private void ensureOpen() {
        if (closed || reader == null || csv == null) {
            log.warn("CSV-поток был закрыт/неинициализирован. Переоткрываю.");
            reopen();
        }
    }

    /** Тихое закрытие (для переоткрытия). */
    private void closeQuietly() {
        try { if (csv != null) csv.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        csv = null;
        reader = null;
        closed = true;
    }

    @Override
    public synchronized void close() {
        closeQuietly();
        log.info("CSVDataReader закрыт.");
    }

    // ================= утилиты =================

    private static boolean useClasspath(String path) {
        return path == null || path.isEmpty() || path.startsWith("classpath:");
    }

    private static String resolveClasspathName(String path) {
        return (path == null || path.isEmpty()) ? "data.csv" : path.substring("classpath:".length());
    }

    private static String printable(String s) {
        return (s == null || s.isEmpty()) ? "<default:classpath:data.csv>" : s;
    }

    /**
     * Компактное представление строки для логов:
     * - первые `maxEntries` колонок в порядке итерации;
     * - значения обрезаются до `maxLen` символов;
     * - остальные колонки замещаются "...(+N more)".
     */
    private static String summarizeRow(Map<String, String> row, int maxEntries, int maxLen) {
        if (row == null || row.isEmpty()) return "{}";
        StringBuilder sb = new StringBuilder("{");
        int i = 0;
        for (Map.Entry<String, String> e : row.entrySet()) {
            if (i == maxEntries) break;
            if (i > 0) sb.append(", ");
            sb.append(e.getKey()).append("=")
                    .append(truncateForLog(e.getValue(), maxLen));
            i++;
        }
        int remaining = row.size() - i;
        if (remaining > 0) {
            sb.append(", ...(+").append(remaining).append(" more)");
        }
        sb.append("}");
        return sb.toString();
    }

    private static String truncateForLog(String v, int maxLen) {
        if (v == null) return "null";
        if (v.length() <= maxLen) return v;
        return v.substring(0, Math.max(0, maxLen - 3)) + "...";
    }

    // На будущее: если нужен стабильный порядок колонок в логах,
    // можно копировать в LinkedHashMap и сортировать ключи.
    @SuppressWarnings("unused")
    private static Map<String, String> copyFirstN(Map<String, String> src, int n) {
        Map<String, String> dst = new LinkedHashMap<>();
        int i = 0;
        for (Map.Entry<String, String> e : src.entrySet()) {
            if (i++ == n) break;
            dst.put(e.getKey(), e.getValue());
        }
        return dst;
    }
}
