package com.example.MTConnect.model;



public final class MTConnectNamespaces {
    private MTConnectNamespaces() {}
    public static final String STREAMS = "urn:mtconnect.org:MTConnectStreams:1.8";
}
