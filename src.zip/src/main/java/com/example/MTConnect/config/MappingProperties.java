package com.example.MTConnect.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "sim.mapping")
public class MappingProperties {
    private List<MapRule> rules;

    public List<MapRule> getRules() { return rules; }
    public void setRules(List<MapRule> rules) { this.rules = rules; }
}
