package com.example.MTConnect.config;

import com.example.MTConnect.mapping.MappingRegistry;
import com.example.MTConnect.mapping.RowMapper;
import com.example.MTConnect.model.MTConnectStreams;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.glassfish.jaxb.runtime.v2.runtime.IllegalAnnotationsException;
import com.example.MTConnect.model.MTConnectStreams;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import org.glassfish.jaxb.runtime.v2.runtime.IllegalAnnotationsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Beans {

    @Bean
    public MappingRegistry mappingRegistry(MappingProperties props) {
        return new MappingRegistry(props);
    }

    @Bean
    public RowMapper rowMapper(MappingRegistry registry) {
        return new RowMapper(registry);
    }

    private static final Logger log = LoggerFactory.getLogger(Beans.class);

    @Bean
    public JAXBContext jaxbContext() {
        try {
            return JAXBContext.newInstance(com.example.MTConnect.model.MTConnectStreams.class);
        } catch (JAXBException ex) {
            log.error("JAXBContext failed: {}", ex.getMessage());

            // пройдём по всей цепочке причин
            Throwable t = ex;
            boolean printed = false;
            while (t != null) {
                if (t.getClass().getName().endsWith("IllegalAnnotationsException")) {
                    printed = true;
                    log.error("---- IllegalAnnotationsException details ----");
                    try {
                        // попытка вызвать t.getErrors()
                        var m = t.getClass().getMethod("getErrors");
                        var errors = (java.util.List<?>) m.invoke(t);
                        for (Object err : errors) {
                            log.error("  -> {}", err.toString()); // обычно включает класс и причину
                        }
                    } catch (Exception reflectEx) {
                        log.error("Couldn't reflect getErrors(): {}", reflectEx.toString());
                    }
                    break;
                }
                t = t.getCause();
            }
            if (!printed) {
                log.error("Full exception follows", ex);
            }
            throw new RuntimeException("JAXBContext failed (see detailed errors above)", ex);
        }
    }
}

