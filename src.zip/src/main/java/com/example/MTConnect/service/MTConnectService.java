package com.example.MTConnect.service;


import com.example.MTConnect.config.DeviceProperties;
import com.example.MTConnect.data.CSVDataReader;
import com.example.MTConnect.mapping.RowMapper;
import com.example.MTConnect.model.*;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.StringWriter;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class MTConnectService {

    private final CSVDataReader csv;
    private final RowMapper mapper;
    private final DeviceProperties device;
    private final JAXBContext jaxb;

    // последовательности и инстанс агента
    private final AtomicLong sequence = new AtomicLong(0);
    private final long instanceId = 1L;
    private final long bufferSize = 8192L;

    // «последний собранный документ»
    private final AtomicReference<MTConnectStreams> lastDoc = new AtomicReference<>();

    public MTConnectService(CSVDataReader csv, RowMapper mapper,
                            DeviceProperties device, JAXBContext jaxb) {
        this.csv = csv;
        this.mapper = mapper;
        this.device = device;
        this.jaxb = jaxb;
    }

    /** Тик: читаем CSV и собираем новый MTConnectStreams. */
    @Scheduled(fixedRateString = "${sim.tickMs:1000}")
    public void tick() {
        Map<String,String> row = csv.getNextRow();
        if (row == null || row.isEmpty()) return;

        long seq = sequence.incrementAndGet();
        Instant now = Instant.now();

        // Собираем всё в общий набор (как раньше)
        Samples allSamples = new Samples();
        Events  allEvents  = new Events();
        Conditions allCond = new Conditions();
        mapper.mapRow(row, now, seq, allSamples, allEvents, allCond, unk -> {});

        // Делаем несколько компонент и раскладываем элементы по coordinate/subType/dataItemId
        ComponentStream xAxis = new ComponentStream("Linear", "X");
        ComponentStream yAxis = new ComponentStream("Linear", "Y");
        ComponentStream zAxis = new ComponentStream("Linear", "Z");
        ComponentStream spindle = new ComponentStream("Rotary", "Spindle");
        ComponentStream systems = new ComponentStream("Systems", "ToolMagazine");

        // Пример распределения только для Samples — идея понятна:
        Samples xS = new Samples(); Samples yS = new Samples(); Samples zS = new Samples();
        Samples spS = new Samples(); // шпиндель
        Samples sysS = new Samples(); // магазины/прочее, при необходимости

        // 1) Позиции/скорости по координате
        allSamples.getPositions().forEach(p -> {
            switch (nullToEmpty(p.getCoordinate())) {
                case "X" -> xS.getPositions().add(p);
                case "Y" -> yS.getPositions().add(p);
                case "Z" -> zS.getPositions().add(p);
                case "S","" -> spS.getPositions().add(p);
            }
        });
        allSamples.getLinearVelocities().forEach(v -> {
            switch (nullToEmpty(v.getCoordinate())) {
                case "X" -> xS.getLinearVelocities().add(v);
                case "Y" -> yS.getLinearVelocities().add(v);
                case "Z" -> zS.getLinearVelocities().add(v);
            }
        });
        allSamples.getRotaryVelocities().forEach(v -> {
            switch (nullToEmpty(v.getCoordinate())) {
                case "S","B","C","" -> spS.getRotaryVelocities().add(v);
            }
        });
        // остальные типы (Temperature/Current/Torque/Voltage/Power/Percentage) — по смыслу.

        // Вкладываем собранные Samples в компоненты (если не пусты)
        if (!isEmpty(xS)) xAxis.setSamples(xS);
        if (!isEmpty(yS)) yAxis.setSamples(yS);
        if (!isEmpty(zS)) zAxis.setSamples(zS);
        if (!isEmpty(spS)) spindle.setSamples(spS);

        // Формируем DeviceStream
        DeviceStream ds = new DeviceStream(device.getName(), device.getUuid());
        ds.getComponentStreams().addAll(
                List.of(xAxis, yAxis, zAxis, spindle, systems)
                        .stream().filter(this::hasAnyData).toList()
        );

        Streams streams = new Streams(List.of(ds));
        StreamsHeader header = new StreamsHeader(
                now.toString(), device.getName(), instanceId, "1.8",
                bufferSize, Math.max(1, seq-bufferSize+1), seq, seq+1);
        lastDoc.set(new MTConnectStreams(header, streams));
    }

    // Вспомогалки — заведи у себя где удобно
    @Contract(value = "!null -> param1", pure = true)
    private static @NotNull String nullToEmpty(String s) { return s == null ? "" : s; }
    private static boolean isEmpty(@NotNull Samples s) {
        return s.getPositions().isEmpty()
                && s.getRotaryPositions().isEmpty()
                && s.getLinearVelocities().isEmpty()
                && s.getRotaryVelocities().isEmpty()
                && s.getFeedrates().isEmpty()
                && s.getTemperatures().isEmpty()
                && s.getCurrents().isEmpty()
                && s.getTorques().isEmpty()
                && s.getVoltages().isEmpty()
                && s.getPowers().isEmpty()
                && s.getPercentages().isEmpty();
    }
    private static boolean isEmpty(@NotNull Events e) {
        return e.getExecutions().isEmpty()
                && e.getAlarms().isEmpty()
                && e.getDiscrete().isEmpty()
                && e.getTexts().isEmpty()
                && e.getNumbers().isEmpty();
    }
    private boolean hasAnyData(@NotNull ComponentStream cs) {
        return (cs.getSamples() != null && !isEmpty(cs.getSamples()))
                || (cs.getEvents() != null && !isEmpty(cs.getEvents()))
                || (cs.getCondition() != null && !cs.getCondition().getEntries().isEmpty());
    }

    /** Отдать текущее состояние в виде XML. */
    public String currentXml() {
        MTConnectStreams doc = lastDoc.get();
        if (doc == null) doc = emptyDoc();

        try (var sw = new StringWriter(2048)) {
            Marshaller m = jaxb.createMarshaller();
            // 1) человекочитаемый XML
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            // 2) XML-декларация (по умолчанию true, но можно явно)
            m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.FALSE);
            // 3) Кодировка
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");

            // 4) (опционально) префиксы неймспейсов — см. следующий раздел
            // configureNamespacePrefixes(m);

            m.marshal(doc, sw);
            return sw.toString();
        } catch (Exception e) {
            throw new RuntimeException("MTConnect marshal error", e);
        }
    }


    /** Пустой документ (на самый первый вызов до первого тика). */
    private MTConnectStreams emptyDoc() {
        Instant now = Instant.now();
        StreamsHeader header = new StreamsHeader(
                now.toString(), device.getName(), instanceId, "1.8",
                bufferSize, 1, 0, 1
        );
        DeviceStream ds = new DeviceStream(device.getName(), device.getUuid());
        Streams streams = new Streams(List.of(ds));
        return new MTConnectStreams(header, streams);
    }
}
