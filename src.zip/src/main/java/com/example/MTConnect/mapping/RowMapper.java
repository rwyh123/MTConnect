package com.example.MTConnect.mapping;

import com.example.MTConnect.config.MapRule;
import com.example.MTConnect.model.*;
import com.example.MTConnect.model.Elements.Conditions.ConditionEntry;
import com.example.MTConnect.model.Elements.Samples.*;
import com.example.MTConnect.model.Events;
import com.example.MTConnect.model.Samples.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

import static com.example.MTConnect.mapping.ValueCodec.*;

public class RowMapper {

    private final MappingRegistry registry;

    public RowMapper(MappingRegistry registry) { this.registry = registry; }

    public void mapRow(
            Map<String,String> row,
            Instant ts, long seq,
            Samples samples, Events events, Conditions conditions,
            Consumer<String> unknownSink // лог неизвестных / метрики
    ) {
        String tsIso = ts.toString();

        for (var entry : row.entrySet()) {
            String key = entry.getKey();
            String raw = entry.getValue();
            if (raw == null || raw.isBlank()) continue;

            Optional<MapRule> r = registry.find(key);
            if (r.isPresent()) {
                applyRule(r.get(), row, tsIso, seq, samples, events, conditions);
                continue;
            }

            // Fallback по значению
            Double num = asDouble(row, key);
            if (num != null) {
                samples.getPercentages().add(new Percentage(key, tsIso, seq, BigDecimal.valueOf(num)));
                unknownSink.accept("NUMERIC_FALLBACK:" + key);
                continue;
            }
            Boolean flag = asBool(row, key);
            if (flag != null) {
                events.getDiscrete().add(new com.example.MTConnect.model.Elements.Events.DiscreteEvent(
                        key, tsIso, seq, flag ? "ON" : "OFF"));
                unknownSink.accept("BOOL_FALLBACK:" + key);
                continue;
            }
            String txt = asText(row, key);
            if (txt != null) {
                events.getTexts().add(new com.example.MTConnect.model.Elements.Events.StringEvent(
                        key, tsIso, seq, txt));
                unknownSink.accept("TEXT_FALLBACK:" + key);
            }
        }
    }

    private void applyRule(
            MapRule r, Map<String,String> row,
            String ts, long seq,
            Samples samples, Events events, Conditions conditions
    ) {
        switch (r.container()) {
            case "Samples" -> emitSample(r, row, ts, seq, samples);
            case "Events" -> emitEvent(r, row, ts, seq, events);
            case "Conditions" -> emitCondition(r, row, ts, seq, conditions);
            default -> { /* ignore */ }
        }
    }

    private void emitSample(MapRule r, Map<String,String> row, String ts, long seq, Samples samples) {
        Double v = asDouble(row, r.csvKey());
        if (v == null) return;
        var val = BigDecimal.valueOf(v);

        switch (r.mtcType()) {
            case "Position" -> samples.getPositions().add(
                    new Position(r.dataItemId(), ts, seq, val));
            case "RotaryPosition" -> samples.getRotaryPositions().add(
                    new RotaryPosition(r.dataItemId(), ts, seq, val, r.coordinate(), r.subType()));
            case "LinearVelocity" -> samples.getLinearVelocities().add(
                    new LinearVelocity(r.dataItemId(), ts, seq, val, r.coordinate()));
            case "RotaryVelocity" -> samples.getRotaryVelocities().add(
                    new RotaryVelocity(r.dataItemId(), ts, seq, val));
            case "Feedrate" -> samples.getFeedrates().add(
                    new Feedrate(r.dataItemId(), ts, seq, val));
            case "Temperature" -> samples.getTemperatures().add(
                    new Temperature(r.dataItemId(), ts, seq, val));
            case "ElectricCurrent" -> samples.getCurrents().add(
                    new ElectricCurrent(r.dataItemId(), ts, seq, val));
            case "Torque" -> samples.getTorques().add(
                    new Torque(r.dataItemId(), ts, seq, val));
            case "Voltage" -> samples.getVoltages().add(
                    new Voltage(r.dataItemId(), ts, seq, val));
            case "Power" -> samples.getPowers().add(
                    new Power(r.dataItemId(), ts, seq, val));
            case "Percentage" -> samples.getPercentages().add(
                    new Percentage(r.dataItemId(), ts, seq, val));
        }
    }

    private void emitEvent(MapRule r, Map<String,String> row, String ts, long seq, Events events) {
        // Сначала пробуем bool → потом long → потом текст
        Boolean b = asBool(row, r.csvKey());
        if (b != null) {
            events.getDiscrete().add(new com.example.MTConnect.model.Elements.Events.DiscreteEvent(
                    r.dataItemId(), ts, seq, b ? "ON" : "OFF"));
            return;
        }
        Long n = asLong(row, r.csvKey());
        if (n != null) {
            events.getNumbers().add(new com.example.MTConnect.model.Elements.Events.LongEvent(
                    r.dataItemId(), ts, seq, n));
            return;
        }
        String s = asText(row, r.csvKey());
        if (s != null) {
            events.getTexts().add(new com.example.MTConnect.model.Elements.Events.StringEvent(
                    r.dataItemId(), ts, seq, s));
        }
    }

    private void emitCondition(MapRule r, Map<String,String> row, String ts, long seq, Conditions conditions) {
        // Базовый пример: текст как описание, уровень — NORMAL
        String txt = asText(row, r.csvKey());
        if (txt == null) return;
        conditions.getEntries().add(new ConditionEntry(
                r.dataItemId(), ts, seq, "NORMAL", txt));
    }
}
