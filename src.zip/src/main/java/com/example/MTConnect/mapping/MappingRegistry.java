package com.example.MTConnect.mapping;

import com.example.MTConnect.config.MapRule;
import com.example.MTConnect.config.MappingProperties;

import java.util.*;
import java.util.regex.*;

public class MappingRegistry {

    private final Map<String, MapRule> byKey = new HashMap<>();
    private final List<Pattern> patterns = List.of(
            // X/Y/Z-axis_position_(MCS|WCS|error)
            Pattern.compile("^(X|Y|Z)-axis_position_(MCS|WCS|[Ee][Rr][Rr][Oo][Rr])$"),
            // Spindle_position_(MCS|WCS|error)
            Pattern.compile("^Spindle_position_(MCS|WCS|[Ee][Rr][Rr][Oo][Rr])$"),
            // *_smoothed_current*
            Pattern.compile("^.*_smoothed_current.*$"),
            // *_smoothed_torque*
            Pattern.compile("^.*_smoothed_torque.*$"),
            // *_smoothed_active_power.*
            Pattern.compile("^.*_smoothed_active_power.*$"),
            // *_intermediate_circuit_voltage|smoothed_DC_voltage_*
            Pattern.compile("^.*(intermediate_circuit_voltage|smoothed_DC_voltage).*$")
    );

    public MappingRegistry(MappingProperties props) {
        if (props.getRules() != null) {
            for (var r : props.getRules()) {
                byKey.put(r.csvKey(), r);
            }
        }
    }

    /** Ищем явное правило, иначе пробуем регулярки. */
    public Optional<MapRule> find(String csvKey) {
        var direct = byKey.get(csvKey);
        if (direct != null) return Optional.of(direct);

        for (var p : patterns) {
            var m = p.matcher(csvKey);
            if (m.matches()) {
                return Optional.of(generateRuleFromPattern(p, m, csvKey));
            }
        }
        return Optional.empty();
    }

    /** Генерация MapRule по семейству имён (эвристики). */
    private MapRule generateRuleFromPattern(Pattern p, Matcher m, String key) {
        String pat = p.pattern();

        if (pat.startsWith("^(X|Y|Z)-axis_position_")) {
            String coord = m.group(1);
            String sub = m.group(2).equalsIgnoreCase("error") ? "ERROR" : m.group(2).toUpperCase();
            return new MapRule(key, "Samples", "Position",
                    coord.toLowerCase() + "_" + sub.toLowerCase(),
                    coord, sub, "MILLIMETER");
        }
        if (pat.startsWith("^Spindle_position_")) {
            String sub = m.group(1).equalsIgnoreCase("error") ? "ERROR" : m.group(1).toUpperCase();
            return new MapRule(key, "Samples", "RotaryPosition",
                    "spindle_pos_" + sub.toLowerCase(), "S", sub, "DEGREE");
        }
        if (pat.equals("^.*_smoothed_current.*$")) {
            return new MapRule(key, "Samples", "ElectricCurrent",
                    normalizeId(key, "current"), null, null, "AMPERE");
        }
        if (pat.equals("^.*_smoothed_torque.*$")) {
            return new MapRule(key, "Samples", "Torque",
                    normalizeId(key, "torque"), null, null, "NEWTON_METER");
        }
        if (pat.equals("^.*_smoothed_active_power.*$")) {
            return new MapRule(key, "Samples", "Power",
                    normalizeId(key, "power"), null, null, "WATT");
        }
        if (pat.equals("^.*(intermediate_circuit_voltage|smoothed_DC_voltage).*$")) {
            return new MapRule(key, "Samples", "Voltage",
                    normalizeId(key, "voltage"), null, null, "VOLT");
        }
        // дефолт (не должен сюда дойти)
        return new MapRule(key, "Events", "StringEvent", key, null, null, null);
    }

    private String normalizeId(String key, String suffix) {
        return key.toLowerCase().replaceAll("[^a-z0-9]+", "_") + "_" + suffix;
    }
}
