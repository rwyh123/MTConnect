package com.example.MTConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
